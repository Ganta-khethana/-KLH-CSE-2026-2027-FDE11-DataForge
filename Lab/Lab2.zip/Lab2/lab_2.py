import pandas as pd
import numpy as np

# Simulate incoming patient data
data = pd.DataFrame({
    'timestamp': pd.date_range(start='2025-07-19', periods=10, freq='min'),
    'heart_rate': np.random.normal(75, 10, 10),
    'temperature': np.random.normal(98.6, 0.5, 10),
    'bp_systolic': np.random.normal(120, 15, 10)
})

# Anomaly detection: flag vitals outside expected ranges
def detect_anomalies(df):
    df['hr_alert'] = df['heart_rate'].apply(lambda x: x < 50 or x > 100)
    df['temp_alert'] = df['temperature'].apply(lambda x: x < 97 or x > 99.5)
    df['bp_alert'] = df['bp_systolic'].apply(lambda x: x < 90 or x > 140)

    # Overall anomaly if any alert is True
    df['anomaly'] = df[['hr_alert', 'temp_alert', 'bp_alert']].any(axis=1)

    return df

# Process the data
processed = detect_anomalies(data)

# Display results
print(processed[['timestamp', 'heart_rate', 'temperature', 'bp_systolic', 'anomaly']])
# Import pandas library
import pandas as pd

# Step 1: Define the essential skills and importance
skills_data = [
    {"Category": "Programming", "Skill": "Python", "Importance": 5},
    {"Category": "Programming", "Skill": "SQL", "Importance": 5},
    {"Category": "ETL Tools", "Skill": "Apache NiFi", "Importance": 4},
    {"Category": "ETL Tools", "Skill": "Apache Airflow", "Importance": 5},
    {"Category": "Big Data", "Skill": "Apache Spark", "Importance": 4},
    {"Category": "Cloud", "Skill": "Azure Data Factory", "Importance": 5},
    {"Category": "Data Modeling", "Skill": "Star Schema", "Importance": 4},
    {"Category": "DevOps", "Skill": "Docker", "Importance": 3},
    {"Category": "Soft Skills", "Skill": "Communication", "Importance": 5},
]

# Step 2: Add your self-assessed proficiency (scale of 1–5)
# Customize this according to your skill level
self_proficiency = {
    "Python": 3,
    "SQL": 2,
    "Apache NiFi": 1,
    "Apache Airflow": 2,
    "Apache Spark": 1,
    "Azure Data Factory": 2,
    "Star Schema": 3,
    "Docker": 2,
    "Communication": 4,
}

# Step 3: Create DataFrame and calculate gap
df = pd.DataFrame(skills_data)

# Map proficiency values to skills
df["Proficiency"] = df["Skill"].map(self_proficiency)

# Calculate skill gap
df["Gap"] = df["Importance"] - df["Proficiency"]

# Display the result
print("=== Skill-Gap Matrix ===\n")
print(df[["Category", "Skill", "Proficiency", "Importance", "Gap"]].to_string(index=False))

# Save the result to an Excel file
df.to_excel("Skill_Gap_Matrix.xlsx", index=False)

print("\nSkill Gap Matrix has been saved as 'Skill_Gap_Matrix.xlsx'.")