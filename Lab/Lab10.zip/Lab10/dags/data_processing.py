from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
import pandas as pd
import os


def process_data():

    input_file = "/opt/airflow/data/raw_data.csv"
    output_file = "/opt/airflow/output/processed_data.csv"

    df = pd.read_csv(input_file)

    print("Raw Data:")
    print(df)

    df = df.drop_duplicates()
    df = df.dropna()

    df["Total"] = df["Quantity"] * df["Price"]

    os.makedirs("/opt/airflow/output", exist_ok=True)

    df.to_csv(output_file, index=False)

    print("Processed Data:")
    print(df)

    print("Data processing completed successfully!")


with DAG(
    dag_id="data_processing_pipeline",
    start_date=datetime(2026, 10, 7),
    schedule=None,
    catchup=False
) as dag:

    process_task = PythonOperator(
        task_id="process_data",
        python_callable=process_data
    )