import pandas as pd
import matplotlib.pyplot as plt

# Load cleaned data
df = pd.read_csv("cleaned_patient_vitals.csv")

# Plot heart rate over time
plt.figure(figsize=(10, 5))
for patient in df['patient_id'].unique():
    patient_data = df[df['patient_id'] == patient]
    plt.plot(pd.to_datetime(patient_data['timestamp']), patient_data['heart_rate'], label=patient)

plt.title("Heart Rate Trends (Last 24 Hours)")
plt.xlabel("Time")
plt.ylabel("Heart Rate (bpm)")
plt.legend(title="Patient ID")
plt.show()

# Alert Summary
alerts = df[df['status'] == 'ALERT']
print(f"Alerts Found: {len(alerts)}")
print(alerts[['patient_id', 'timestamp', 'heart_rate', 'spo2', 'temperature']])
