import pandas as pd

# Load raw data
df = pd.read_csv("raw_patient_vitals.csv")
print("Loaded raw data")

# Data Cleaning: Remove outliers
df_clean = df[
    (df['heart_rate'] >= 40) & (df['heart_rate'] <= 180) &
    (df['spo2'] >= 80) & (df['spo2'] <= 100) &
    (df['temperature'] >= 34) & (df['temperature'] <= 42)
]
print(f" Cleaned data: {len(df_clean)} records (from {len(df)})")

# Transformation: Add status column
def classify_status(row):
    if row['heart_rate'] < 60 or row['heart_rate'] > 100:
        return 'ALERT'
    if row['spo2'] < 90:
        return 'ALERT'
    if row['temperature'] > 38:
        return 'ALERT'
    return 'NORMAL'

df_clean['status'] = df_clean.apply(classify_status, axis=1)

# Aggregation: Average vitals per patient
agg_df = df_clean.groupby('patient_id').agg({
    'heart_rate': 'mean',
    'spo2': 'mean',
    'temperature': 'mean'
}).reset_index()
agg_df.rename(columns={
    'heart_rate': 'avg_heart_rate',
    'spo2': 'avg_spo2',
    'temperature': 'avg_temperature'
}, inplace=True)

# Store cleaned and aggregated data
df_clean.to_csv("cleaned_patient_vitals.csv", index=False)
agg_df.to_csv("aggregated_patient_vitals.csv", index=False)
print(" Saved cleaned_patient_vitals.csv and aggregated_patient_vitals.csv")

