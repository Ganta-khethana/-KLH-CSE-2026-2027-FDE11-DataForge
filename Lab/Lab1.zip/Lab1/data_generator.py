import pandas as pd
import random
from datetime import datetime, timedelta

# Generate synthetic patient vitals data
def generate_vitals(num_records=100):
    data = []
    start_time = datetime.now() - timedelta(days=1)
    for i in range(num_records):
        record = {
            "patient_id": f"P{random.randint(1000, 9999)}",
            "timestamp": (start_time + timedelta(minutes=i*10)).strftime('%Y-%m-%d %H:%M:%S'),
            "heart_rate": random.randint(50, 120),  # bpm
            "spo2": random.randint(85, 100),       # %
            "temperature": round(random.uniform(35.0, 39.0), 1)  # °C
        }
        data.append(record)
    return pd.DataFrame(data)

# Save to CSV (raw data)
df = generate_vitals()
df.to_csv("raw_patient_vitals.csv", index=False)
print("Generated raw_patient_vitals.csv")
