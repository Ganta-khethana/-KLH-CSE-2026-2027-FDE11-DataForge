import os

PYTHON_PATH = r"C:\Users\Khethana\AppData\Local\Programs\Python\Python311\python.exe"

os.environ["PYSPARK_PYTHON"] = PYTHON_PATH
os.environ["PYSPARK_DRIVER_PYTHON"] = PYTHON_PATH
from pyspark.sql import SparkSession
from pyspark.sql.functions import avg
import pandas as pd
import time
from streamz import Stream
import inspect
import matplotlib.pyplot as plt
# ------------------------------------
# Data Setup
# ------------------------------------

historical_data = [
    ("2025-08-01", "user1", 5),
    ("2025-08-01", "user2", 3),
    ("2025-08-02", "user1", 4),
    ("2025-08-02", "user3", 2),
]

live_events = [
    ("2025-08-03", "user4", 5),
    ("2025-08-03", "user5", 1),
]
# ------------------------------------
# Lambda Architecture Simulation
# ------------------------------------

start_lambda = time.time()

# Batch Layer
spark = SparkSession.builder \
    .master("local[*]") \
    .appName("LambdaDemo") \
    .getOrCreate()

df_hist = spark.createDataFrame(
    historical_data,
    ["date", "user", "score"]
)

batch_result = df_hist.groupBy("date").agg(
    avg("score").alias("avg_score")
)

# Speed Layer
live_results = []

def process_live(event):
    df = pd.DataFrame(
        [event],
        columns=["date", "user", "score"]
    )
    avg_val = df["score"].mean()
    live_results.append((event[0], avg_val))

source = Stream()
source.map(process_live)

for e in live_events:
    source.emit(e)

# Serving Layer
batch_pd = batch_result.toPandas()

live_pd = pd.DataFrame(
    live_results,
    columns=["date", "avg_score"]
)

final_lambda = pd.concat(
    [batch_pd, live_pd]
).reset_index(drop=True)

end_lambda = time.time()

lambda_time = end_lambda - start_lambda

lambda_throughput = (
    len(historical_data) + len(live_events)
) / lambda_time

lambda_code_lines = len(
    inspect.getsource(process_live).split("\n")
)
# ------------------------------------
# Kappa Architecture Simulation
# ------------------------------------

start_kappa = time.perf_counter()

kappa_results = []

def kappa_process(event):
    df = pd.DataFrame(
        [event],
        columns=["date", "user", "score"]
    )

    avg_val = df["score"].mean()

    kappa_results.append(
        (event[0], avg_val)
    )

kappa_source = Stream()
kappa_source.map(kappa_process)

# Replay historical + live
all_events = historical_data + live_events

for e in all_events:
    kappa_source.emit(e)

end_kappa = time.perf_counter()

kappa_time = end_kappa - start_kappa

kappa_throughput = (
    len(all_events) / kappa_time
)

kappa_code_lines = len(
    inspect.getsource(kappa_process).split("\n")
)
# ------------------------------------
# Performance Comparison DataFrame
# ------------------------------------

performance_df = pd.DataFrame([
    [
        "Lambda",
        lambda_time,
        lambda_throughput,
        lambda_code_lines
    ],
    [
        "Kappa",
        kappa_time,
        kappa_throughput,
        kappa_code_lines
    ]
], columns=[
    "Architecture",
    "Total Time (s)",
    "Throughput (events/sec)",
    "Processing Logic LOC"
])

print("=== Lambda Final Output ===")
print(final_lambda)

print("\n=== Kappa Final Output ===")
print(
    pd.DataFrame(
        kappa_results,
        columns=["date", "avg_score"]
    )
)

print("\n=== PERFORMANCE COMPARISON ===")
print(performance_df)
# ------------------------------------
# Plot Comparison Charts
# ------------------------------------

fig, ax = plt.subplots(1, 2, figsize=(10, 4))

# Total Time Chart
times = performance_df["Total Time (s)"]

ax[0].bar(
    performance_df["Architecture"],
    times
)

for i, v in enumerate(times):
    ax[0].text(
        i,
        v + max(times) * 0.05,
        f"{v:.4f}",
        ha="center"
    )

ax[0].set_title("Total Processing Time")
ax[0].set_ylabel("Seconds")

# Throughput Chart
throughputs = performance_df[
    "Throughput (events/sec)"
]

ax[1].bar(
    performance_df["Architecture"],
    throughputs
)

for i, v in enumerate(throughputs):
    ax[1].text(
        i,
        v + max(throughputs) * 0.05,
        f"{v:.2f}",
        ha="center"
    )

ax[1].set_title("Throughput")
ax[1].set_ylabel("Events/sec")

plt.suptitle(
    "Lambda vs Kappa Performance Comparison"
)

plt.tight_layout()
plt.show()