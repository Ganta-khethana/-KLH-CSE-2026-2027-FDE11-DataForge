import pandas as pd
import sqlite3

# Define 20 sales products
products_data = [
    [1, "Laptop", 500, 2024],
    [2, "Smartphone", 400, 2024],
    [3, "Tablet", 350, 2024],
    [4, "Headphones", 120, 2024],
    [5, "Smartwatch", 200, 2024],
    [6, "Camera", 450, 2024],
    [7, "Printer", 250, 2024],
    [8, "Monitor", 300, 2024],
    [9, "Keyboard", 50, 2024],
    [10, "Mouse", 40, 2024],
    [11, "Speaker", 100, 2024],
    [12, "Router", 80, 2024],
    [13, "External HDD", 150, 2024],
    [14, "Microphone", 90, 2024],
    [15, "Charger", 30, 2024],
    [16, "Projector", 600, 2024],
    [17, "Drone", 800, 2024],
    [18, "VR Headset", 350, 2024],
    [19, "Smart TV", 700, 2024],
    [20, "Gaming Console", 500, 2024]
]

# Create DataFrame
products_df = pd.DataFrame(
    products_data,
    columns=["id", "product", "price", "year"]
)

# Display the DataFrame
print("=== PRODUCT DATA ===")
print(products_df)

# Save to CSV
products_df.to_csv("products.csv", index=False)
print("\nproducts.csv created successfully.")

# Load into SQLite
conn = sqlite3.connect("products.db")

products_df.to_sql(
    "products",
    conn,
    if_exists="replace",
    index=False
)

# Query row count
row_count = conn.execute(
    "SELECT COUNT(*) FROM products;"
).fetchone()[0]

print(f"\nInserted {row_count} rows into 'products' table.")

# Fetch top 5 expensive products
top_products = conn.execute(
    "SELECT product, price FROM products ORDER BY price DESC LIMIT 5;"
).fetchall()

print("\nTop 5 expensive products:")

for product in top_products:
    print(product)

# Close database
conn.close()