import os
import sys

os.environ["PYSPARK_PYTHON"] = sys.executable
os.environ["PYSPARK_DRIVER_PYTHON"] = sys.executable

import time
import pandas as pd
import matplotlib.pyplot as plt
from pyspark.sql import SparkSession
from pyspark.sql.functions import avg
\


# -----------------------------
# DATA
# -----------------------------

historical_data = [
    ("2025-08-01", "user1", 5),
    ("2025-08-01", "user2", 3),
    ("2025-08-02", "user1", 4),
    ("2025-08-02", "user3", 2)
]

live_events = [
    ("2025-08-03", "user4", 5),
    ("2025-08-03", "user5", 1)
]

# =============================
# LAMBDA ARCHITECTURE
# =============================

start_lambda = time.time()

# Batch Layer
spark = (
    SparkSession.builder
    .master("local[2]")
    .appName("LambdaDemo")
    .getOrCreate()
)

df_hist = spark.createDataFrame(
    historical_data,
    ["date", "user", "score"]
)

batch_result = (
    df_hist
    .groupBy("date")
    .agg(avg("score").alias("avg_score"))
)

# Speed Layer
live_results = []

for event in live_events:
    live_results.append(
        (event[0], float(event[2]))
    )

# Serving Layer
batch_pd = batch_result.toPandas()

live_pd = pd.DataFrame(
    live_results,
    columns=["date", "avg_score"]
)

final_lambda = pd.concat(
    [batch_pd, live_pd],
    ignore_index=True
)

end_lambda = time.time()

lambda_time = end_lambda - start_lambda

lambda_throughput = (
    len(historical_data) + len(live_events)
) / lambda_time

print("\n===== LAMBDA ARCHITECTURE =====")
print(final_lambda)

print("\nExecution Time:",
      lambda_time, "seconds")

print("Throughput:",
      lambda_throughput, "events/second")


# =============================
# KAPPA ARCHITECTURE
# =============================

start_kappa = time.time()

kappa_results = []

# Single processing pipeline
all_events = historical_data + live_events

for event in all_events:
    kappa_results.append(
        (event[0], float(event[2]))
    )

end_kappa = time.time()

kappa_time = max(end_kappa - start_kappa, 0.000001)
kappa_throughput = (
    len(all_events) / max(kappa_time, 0.000001)
)

kappa_df = pd.DataFrame(
    kappa_results,
    columns=["date", "avg_score"]
)

print("\n===== KAPPA ARCHITECTURE =====")
print(kappa_df)

print("\nExecution Time:",
      kappa_time, "seconds")

print("Throughput:",
      kappa_throughput, "events/second")


# =============================
# COMPARISON
# =============================

performance_df = pd.DataFrame([
    ["Lambda", lambda_time, lambda_throughput],
    ["Kappa", kappa_time, kappa_throughput]
],
columns=[
    "Architecture",
    "Execution Time",
    "Throughput"
])

print("\n===== PERFORMANCE COMPARISON =====")
print(performance_df)


# =============================
# GRAPH
# =============================

plt.figure(figsize=(8, 5))

plt.bar(
    performance_df["Architecture"],
    performance_df["Throughput"]
)

plt.title("Lambda vs Kappa Throughput")
plt.xlabel("Architecture")
plt.ylabel("Events per Second")

plt.show()

spark.stop()