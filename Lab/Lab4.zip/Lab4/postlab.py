import os
import sys

# Tell Spark to use the current Python
os.environ["PYSPARK_PYTHON"] = sys.executable
os.environ["PYSPARK_DRIVER_PYTHON"] = sys.executable

import time
import pandas as pd
import matplotlib.pyplot as plt

from pyspark.sql import SparkSession
from pyspark.sql.functions import avg, max as spark_max


# =====================================================
# POST LAB - IoT SENSOR MONITORING
# =====================================================

print("\n======================================")
print("     IoT SENSOR MONITORING")
print("     Lambda vs Kappa Architecture")
print("======================================\n")


# =====================================================
# SENSOR DATA
# =====================================================

historical_data = [
    ("2025-08-01", "S1", 25),
    ("2025-08-01", "S2", 30),
    ("2025-08-01", "S3", 28),
    ("2025-08-02", "S1", 32),
    ("2025-08-02", "S2", 35),
    ("2025-08-02", "S3", 29),
    ("2025-08-03", "S1", 40),
    ("2025-08-03", "S2", 38),
]

live_events = [
    ("2025-08-03", "S1", 45),
    ("2025-08-03", "S2", 31),
    ("2025-08-03", "S3", 50),
    ("2025-08-03", "S4", 27),
]


# =====================================================
# LAMBDA ARCHITECTURE
# =====================================================

print("===== LAMBDA ARCHITECTURE =====")

lambda_start = time.perf_counter()


# -----------------------------
# Batch Layer
# -----------------------------

spark = (
    SparkSession.builder
    .master("local[2]")
    .appName("IoT_Lambda")
    .getOrCreate()
)

historical_df = spark.createDataFrame(
    historical_data,
    ["date", "sensor", "temperature"]
)

batch_result = (
    historical_df
    .groupBy("date")
    .agg(
        avg("temperature").alias("average_temperature"),
        spark_max("temperature").alias("maximum_temperature")
    )
)

print("\nBatch Layer Result:")
batch_result.show()


# -----------------------------
# Speed Layer
# -----------------------------

live_alerts = []

for event in live_events:

    date = event[0]
    sensor = event[1]
    temperature = event[2]

    if temperature > 40:
        live_alerts.append(
            (date, sensor, temperature, "ALERT")
        )
    else:
        live_alerts.append(
            (date, sensor, temperature, "NORMAL")
        )


live_df = pd.DataFrame(
    live_alerts,
    columns=[
        "date",
        "sensor",
        "temperature",
        "status"
    ]
)

print("Speed Layer Result:")
print(live_df)


lambda_end = time.perf_counter()

lambda_time = lambda_end - lambda_start

lambda_events = len(historical_data) + len(live_events)

lambda_throughput = lambda_events / max(
    lambda_time,
    0.000001
)


# =====================================================
# KAPPA ARCHITECTURE
# =====================================================

print("\n===== KAPPA ARCHITECTURE =====")

kappa_start = time.perf_counter()


# One single processing pipeline
all_events = historical_data + live_events

kappa_results = []

for event in all_events:

    date = event[0]
    sensor = event[1]
    temperature = event[2]

    if temperature > 40:
        status = "ALERT"
    else:
        status = "NORMAL"

    kappa_results.append(
        (date, sensor, temperature, status)
    )


kappa_df = pd.DataFrame(
    kappa_results,
    columns=[
        "date",
        "sensor",
        "temperature",
        "status"
    ]
)

kappa_end = time.perf_counter()

kappa_time = max(
    kappa_end - kappa_start,
    0.000001
)

kappa_events = len(all_events)

kappa_throughput = (
    kappa_events / kappa_time
)


print("\nSingle Stream Processing Result:")
print(kappa_df)


# =====================================================
# PERFORMANCE COMPARISON
# =====================================================

comparison = pd.DataFrame(
    [
        [
            "Lambda",
            lambda_time,
            lambda_throughput
        ],
        [
            "Kappa",
            kappa_time,
            kappa_throughput
        ]
    ],
    columns=[
        "Architecture",
        "Execution Time",
        "Throughput"
    ]
)


print("\n======================================")
print("       PERFORMANCE COMPARISON")
print("======================================")

print(comparison)


# =====================================================
# RECOMMENDATION
# =====================================================

print("\n======================================")
print("             RECOMMENDATION")
print("======================================")

print(
    "Kappa Architecture is recommended for IoT "
    "sensor monitoring because IoT systems continuously "
    "generate real-time sensor data. Kappa uses a single "
    "stream-processing pipeline and is simpler to maintain."
)


# =====================================================
# GRAPH
# =====================================================

plt.figure(figsize=(8, 5))

plt.bar(
    comparison["Architecture"],
    comparison["Throughput"]
)

plt.title(
    "IoT Sensor Monitoring - Lambda vs Kappa"
)

plt.xlabel("Architecture")

plt.ylabel(
    "Throughput (Events per Second)"
)

plt.show()


# Stop Spark
spark.stop()