import pandas as pd
import sqlite3

# Step 2: Simulate source data
data = {
    "id": [1, 2, 3, 4, 5],
    "name": ["Alice", "Bob", "Charlie", "David", "Eva"],
    "age": [25, 30, 35, 40, 28],
    "salary": [50000, 60000, 75000, 80000, 65000]
}

df = pd.DataFrame(data)

# Save as CSV file
csv_file = "employees.csv"
df.to_csv(csv_file, index=False)

print("Source CSV created successfully!")
print(df)


# Step 3: Connect to SQLite
conn = sqlite3.connect("company.db")
cursor = conn.cursor()

# Create employees table
cursor.execute("""
CREATE TABLE IF NOT EXISTS employees (
    id INTEGER PRIMARY KEY,
    name TEXT,
    age INTEGER,
    salary REAL
)
""")

conn.commit()

print("Database & Table ready!")


# Step 4: Read CSV in batch mode
batch_df = pd.read_csv("employees.csv")

print("\nBatch Data Read from CSV:")
print(batch_df)


# Step 5: Ingest data into SQLite
batch_df.to_sql("employees", conn, if_exists="replace", index=False)

print("\nBatch ingestion completed!")
print("Data written to SQLite.")


# Step 6: Verify data
query = "SELECT * FROM employees"

result = pd.read_sql(query, conn)

print("\nData inside SQLite database:")
print(result)

# Close database connection
conn.close()