import pandas as pd
import sqlite3
from graphviz import Digraph


# ==========================================
# 1. CONNECT TO EXISTING DATABASE
# ==========================================

conn = sqlite3.connect("retail_star_snowflake.db")

print("Database connected successfully.")


# ==========================================
# 2. DISPLAY TABLES
# ==========================================

print("\n--- STAR SCHEMA TABLES ---")

print("\nProduct Dimension:")
print(pd.read_sql_query("SELECT * FROM dim_product", conn))

print("\nCustomer Dimension:")
print(pd.read_sql_query("SELECT * FROM dim_customer", conn))

print("\nStore Dimension:")
print(pd.read_sql_query("SELECT * FROM dim_store", conn))

print("\nTime Dimension:")
print(pd.read_sql_query("SELECT * FROM dim_time", conn))

print("\nFact Sales:")
print(pd.read_sql_query("SELECT * FROM fact_sales", conn))


print("\n--- SNOWFLAKE SCHEMA TABLES ---")

print("\nCategory Dimension:")
print(pd.read_sql_query("SELECT * FROM dim_category", conn))

print("\nSnowflake Product Dimension:")
print(pd.read_sql_query("SELECT * FROM dim_product_snowflake", conn))


# ==========================================
# 3. STAR SCHEMA DIAGRAM
# ==========================================

star = Digraph("Star Schema", format="png")

star.attr(rankdir="LR")

star.node(
    "Fact",
    """<
    <TABLE BORDER="1" CELLBORDER="1" CELLSPACING="0">
    <TR><TD BGCOLOR="lightblue"><B>FACT_SALES</B></TD></TR>
    <TR><TD>PK sale_id</TD></TR>
    <TR><TD>FK product_id</TD></TR>
    <TR><TD>FK customer_id</TD></TR>
    <TR><TD>FK store_id</TD></TR>
    <TR><TD>FK time_id</TD></TR>
    <TR><TD>quantity</TD></TR>
    <TR><TD>sales_amount</TD></TR>
    </TABLE>
    >""",
    shape="plaintext"
)

star.node(
    "Product",
    """<
    <TABLE BORDER="1" CELLBORDER="1" CELLSPACING="0">
    <TR><TD BGCOLOR="lightgrey"><B>DIM_PRODUCT</B></TD></TR>
    <TR><TD>PK product_id</TD></TR>
    <TR><TD>product_name</TD></TR>
    <TR><TD>category</TD></TR>
    </TABLE>
    >""",
    shape="plaintext"
)

star.node(
    "Customer",
    """<
    <TABLE BORDER="1" CELLBORDER="1" CELLSPACING="0">
    <TR><TD BGCOLOR="lightgrey"><B>DIM_CUSTOMER</B></TD></TR>
    <TR><TD>PK customer_id</TD></TR>
    <TR><TD>customer_name</TD></TR>
    <TR><TD>location</TD></TR>
    </TABLE>
    >""",
    shape="plaintext"
)

star.node(
    "Store",
    """<
    <TABLE BORDER="1" CELLBORDER="1" CELLSPACING="0">
    <TR><TD BGCOLOR="lightgrey"><B>DIM_STORE</B></TD></TR>
    <TR><TD>PK store_id</TD></TR>
    <TR><TD>store_name</TD></TR>
    <TR><TD>region</TD></TR>
    </TABLE>
    >""",
    shape="plaintext"
)

star.node(
    "Time",
    """<
    <TABLE BORDER="1" CELLBORDER="1" CELLSPACING="0">
    <TR><TD BGCOLOR="lightgrey"><B>DIM_TIME</B></TD></TR>
    <TR><TD>PK time_id</TD></TR>
    <TR><TD>date</TD></TR>
    <TR><TD>day</TD></TR>
    </TABLE>
    >""",
    shape="plaintext"
)

star.edge("Fact", "Product")
star.edge("Fact", "Customer")
star.edge("Fact", "Store")
star.edge("Fact", "Time")

star.render("postlab_star_schema", cleanup=True)

print("\nStar Schema diagram created.")


# ==========================================
# 4. SNOWFLAKE SCHEMA DIAGRAM
# ==========================================

snow = Digraph("Snowflake Schema", format="png")

snow.attr(rankdir="LR")

snow.node(
    "Fact",
    """<
    <TABLE BORDER="1" CELLBORDER="1" CELLSPACING="0">
    <TR><TD BGCOLOR="lightblue"><B>FACT_SALES</B></TD></TR>
    <TR><TD>PK sale_id</TD></TR>
    <TR><TD>FK product_id</TD></TR>
    <TR><TD>FK customer_id</TD></TR>
    <TR><TD>FK store_id</TD></TR>
    <TR><TD>FK time_id</TD></TR>
    <TR><TD>quantity</TD></TR>
    <TR><TD>sales_amount</TD></TR>
    </TABLE>
    >""",
    shape="plaintext"
)

snow.node(
    "Product",
    """<
    <TABLE BORDER="1" CELLBORDER="1" CELLSPACING="0">
    <TR><TD BGCOLOR="lightgrey"><B>DIM_PRODUCT</B></TD></TR>
    <TR><TD>PK product_id</TD></TR>
    <TR><TD>product_name</TD></TR>
    <TR><TD>FK category_id</TD></TR>
    </TABLE>
    >""",
    shape="plaintext"
)

snow.node(
    "Category",
    """<
    <TABLE BORDER="1" CELLBORDER="1" CELLSPACING="0">
    <TR><TD BGCOLOR="lightgrey"><B>DIM_CATEGORY</B></TD></TR>
    <TR><TD>PK category_id</TD></TR>
    <TR><TD>category_name</TD></TR>
    </TABLE>
    >""",
    shape="plaintext"
)

snow.node(
    "Customer",
    """<
    <TABLE BORDER="1" CELLBORDER="1" CELLSPACING="0">
    <TR><TD BGCOLOR="lightgrey"><B>DIM_CUSTOMER</B></TD></TR>
    <TR><TD>PK customer_id</TD></TR>
    <TR><TD>customer_name</TD></TR>
    <TR><TD>location</TD></TR>
    </TABLE>
    >""",
    shape="plaintext"
)

snow.node(
    "Store",
    """<
    <TABLE BORDER="1" CELLBORDER="1" CELLSPACING="0">
    <TR><TD BGCOLOR="lightgrey"><B>DIM_STORE</B></TD></TR>
    <TR><TD>PK store_id</TD></TR>
    <TR><TD>store_name</TD></TR>
    <TR><TD>region</TD></TR>
    </TABLE>
    >""",
    shape="plaintext"
)

snow.node(
    "Time",
    """<
    <TABLE BORDER="1" CELLBORDER="1" CELLSPACING="0">
    <TR><TD BGCOLOR="lightgrey"><B>DIM_TIME</B></TD></TR>
    <TR><TD>PK time_id</TD></TR>
    <TR><TD>date</TD></TR>
    <TR><TD>day</TD></TR>
    </TABLE>
    >""",
    shape="plaintext"
)

snow.edge("Fact", "Product")
snow.edge("Fact", "Customer")
snow.edge("Fact", "Store")
snow.edge("Fact", "Time")

snow.edge("Product", "Category")

snow.render("postlab_snowflake_schema", cleanup=True)

print("Snowflake Schema diagram created.")


# ==========================================
# 5. NORMALIZATION QUERY
# ==========================================

query = """
SELECT
    p.product_name,
    c.category_name
FROM dim_product_snowflake p
JOIN dim_category c
ON p.category_id = c.category_id;
"""

result = pd.read_sql_query(query, conn)

print("\n--- Product and Category Relationship ---")
print(result)


# ==========================================
# 6. TOTAL SALES BY CATEGORY
# ==========================================

query2 = """
SELECT
    c.category_name,
    SUM(f.sales_amount) AS total_sales
FROM fact_sales f
JOIN dim_product_snowflake p
ON f.product_id = p.product_id
JOIN dim_category c
ON p.category_id = c.category_id
GROUP BY c.category_name;
"""

result2 = pd.read_sql_query(query2, conn)

print("\n--- Total Sales by Category ---")
print(result2)


# ==========================================
# 7. CLOSE DATABASE
# ==========================================

conn.close()

print("\nPost Lab completed successfully.")