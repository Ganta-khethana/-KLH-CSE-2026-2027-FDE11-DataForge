import pandas as pd
import sqlite3
from graphviz import Digraph


# =========================================================
# 1. STAR SCHEMA DATA
# =========================================================

dim_product = pd.DataFrame({
    "product_id": [1, 2, 3],
    "product_name": ["Laptop", "Smartphone", "Headphones"],
    "category": ["Electronics", "Electronics", "Accessories"]
})

dim_customer = pd.DataFrame({
    "customer_id": [101, 102, 103],
    "customer_name": ["Alice", "Bob", "Charlie"],
    "location": ["New York", "California", "Texas"]
})

dim_store = pd.DataFrame({
    "store_id": [10, 11],
    "store_name": ["Store A", "Store B"],
    "region": ["East", "West"]
})

dim_time = pd.DataFrame({
    "time_id": [20230101, 20230102, 20230103],
    "date": ["2023-01-01", "2023-01-02", "2023-01-03"],
    "day": ["Sunday", "Monday", "Tuesday"]
})

fact_sales = pd.DataFrame({
    "sale_id": [1, 2, 3, 4],
    "product_id": [1, 2, 3, 1],
    "customer_id": [101, 102, 103, 101],
    "store_id": [10, 11, 10, 10],
    "time_id": [20230101, 20230102, 20230103, 20230101],
    "quantity": [2, 1, 4, 1],
    "sales_amount": [2000, 800, 400, 1000]
})


# =========================================================
# DISPLAY STAR SCHEMA TABLES
# =========================================================

print("\n--- Product Dimension ---")
print(dim_product)

print("\n--- Customer Dimension ---")
print(dim_customer)

print("\n--- Store Dimension ---")
print(dim_store)

print("\n--- Time Dimension ---")
print(dim_time)

print("\n--- Fact Sales ---")
print(fact_sales)


# =========================================================
# 2. SNOWFLAKE SCHEMA DATA
# =========================================================

dim_category = pd.DataFrame({
    "category_id": [1, 2],
    "category_name": ["Electronics", "Accessories"]
})

dim_product_snowflake = pd.DataFrame({
    "product_id": [1, 2, 3],
    "product_name": ["Laptop", "Smartphone", "Headphones"],
    "category_id": [1, 1, 2]
})


# =========================================================
# DISPLAY SNOWFLAKE TABLES
# =========================================================

print("\n--- Snowflake Category ---")
print(dim_category)

print("\n--- Snowflake Product ---")
print(dim_product_snowflake)


# =========================================================
# 3. STAR SCHEMA DIAGRAM
# Matches the structure shown in the PDF
# =========================================================

star = Digraph("Star Schema", format="png")

star.attr(
    rankdir="LR",
    size="10,6",
    bgcolor="white"
)

# Fact Table
star.node(
    "Fact",
    '''<
    <TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0">
        <TR>
            <TD BGCOLOR="lightblue">
                <B>FACT TABLE</B>
            </TD>
        </TR>
        <TR><TD>Product ID</TD></TR>
        <TR><TD>Time ID</TD></TR>
        <TR><TD>Promotion ID</TD></TR>
        <TR><TD>Customer ID</TD></TR>
        <TR><TD>Revenue</TD></TR>
        <TR><TD>Units Sold</TD></TR>
    </TABLE>
    >''',
    shape="plaintext"
)

# Product Dimension
star.node(
    "Product",
    '''<
    <TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0">
        <TR>
            <TD BGCOLOR="lightgrey">
                <B>PRODUCT DIM</B>
            </TD>
        </TR>
        <TR><TD>Product ID</TD></TR>
        <TR><TD>Product Name</TD></TR>
        <TR><TD>Unit Price</TD></TR>
        <TR><TD>Product Line</TD></TR>
    </TABLE>
    >''',
    shape="plaintext"
)

# Time Dimension
star.node(
    "Time",
    '''<
    <TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0">
        <TR>
            <TD BGCOLOR="lightgrey">
                <B>TIME DIM</B>
            </TD>
        </TR>
        <TR><TD>Time ID</TD></TR>
        <TR><TD>Order Date</TD></TR>
        <TR><TD>Month</TD></TR>
        <TR><TD>Quarter</TD></TR>
        <TR><TD>Year</TD></TR>
    </TABLE>
    >''',
    shape="plaintext"
)

# Promotion Dimension
star.node(
    "Promotion",
    '''<
    <TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0">
        <TR>
            <TD BGCOLOR="lightgrey">
                <B>PROMOTION DIM</B>
            </TD>
        </TR>
        <TR><TD>Promotion ID</TD></TR>
        <TR><TD>Promo Name</TD></TR>
        <TR><TD>Ad Type</TD></TR>
        <TR><TD>Coupon Type</TD></TR>
        <TR><TD>Price Reduction Type</TD></TR>
    </TABLE>
    >''',
    shape="plaintext"
)

# Customer Dimension
star.node(
    "Customer",
    '''<
    <TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0">
        <TR>
            <TD BGCOLOR="lightgrey">
                <B>CUSTOMER DIM</B>
            </TD>
        </TR>
        <TR><TD>Customer ID</TD></TR>
        <TR><TD>Name</TD></TR>
        <TR><TD>City</TD></TR>
        <TR><TD>Zip</TD></TR>
    </TABLE>
    >''',
    shape="plaintext"
)

# Connections
star.edge("Fact", "Product")
star.edge("Fact", "Time")
star.edge("Fact", "Promotion")
star.edge("Fact", "Customer")

star.render(
    "star_schema",
    format="png",
    cleanup=True
)

print("\nStar Schema diagram created: star_schema.png")


# =========================================================
# 4. SNOWFLAKE SCHEMA DIAGRAM
# Matches the PDF structure + Category
# =========================================================

snow = Digraph("Snowflake Schema", format="png")

snow.attr(
    rankdir="LR",
    size="10,6",
    bgcolor="white"
)

# Fact Table
snow.node(
    "Fact",
    '''<
    <TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0">
        <TR>
            <TD BGCOLOR="lightblue">
                <B>FACT TABLE</B>
            </TD>
        </TR>
        <TR><TD>Product ID</TD></TR>
        <TR><TD>Time ID</TD></TR>
        <TR><TD>Promotion ID</TD></TR>
        <TR><TD>Customer ID</TD></TR>
        <TR><TD>Revenue</TD></TR>
        <TR><TD>Units Sold</TD></TR>
    </TABLE>
    >''',
    shape="plaintext"
)

# Product Dimension
snow.node(
    "Product",
    '''<
    <TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0">
        <TR>
            <TD BGCOLOR="lightgrey">
                <B>PRODUCT DIM</B>
            </TD>
        </TR>
        <TR><TD>Product ID</TD></TR>
        <TR><TD>Product Name</TD></TR>
        <TR><TD>Unit Price</TD></TR>
        <TR><TD>Category ID</TD></TR>
    </TABLE>
    >''',
    shape="plaintext"
)

# Category Dimension
snow.node(
    "Category",
    '''<
    <TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0">
        <TR>
            <TD BGCOLOR="lightgrey">
                <B>CATEGORY DIM</B>
            </TD>
        </TR>
        <TR><TD>Category ID</TD></TR>
        <TR><TD>Category Name</TD></TR>
    </TABLE>
    >''',
    shape="plaintext"
)

# Time Dimension
snow.node(
    "Time",
    '''<
    <TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0">
        <TR>
            <TD BGCOLOR="lightgrey">
                <B>TIME DIM</B>
            </TD>
        </TR>
        <TR><TD>Time ID</TD></TR>
        <TR><TD>Order Date</TD></TR>
        <TR><TD>Month</TD></TR>
        <TR><TD>Quarter</TD></TR>
        <TR><TD>Year</TD></TR>
    </TABLE>
    >''',
    shape="plaintext"
)

# Promotion Dimension
snow.node(
    "Promotion",
    '''<
    <TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0">
        <TR>
            <TD BGCOLOR="lightgrey">
                <B>PROMOTION DIM</B>
            </TD>
        </TR>
        <TR><TD>Promotion ID</TD></TR>
        <TR><TD>Promo Name</TD></TR>
        <TR><TD>Ad Type</TD></TR>
        <TR><TD>Coupon Type</TD></TR>
        <TR><TD>Price Reduction Type</TD></TR>
    </TABLE>
    >''',
    shape="plaintext"
)

# Customer Dimension
snow.node(
    "Customer",
    '''<
    <TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0">
        <TR>
            <TD BGCOLOR="lightgrey">
                <B>CUSTOMER DIM</B>
            </TD>
        </TR>
        <TR><TD>Customer ID</TD></TR>
        <TR><TD>Name</TD></TR>
        <TR><TD>City</TD></TR>
        <TR><TD>Zip</TD></TR>
    </TABLE>
    >''',
    shape="plaintext"
)

# Fact → Dimensions
snow.edge("Fact", "Product")
snow.edge("Fact", "Time")
snow.edge("Fact", "Promotion")
snow.edge("Fact", "Customer")

# Snowflake relationship
snow.edge("Product", "Category")

snow.render(
    "snowflake_schema",
    format="png",
    cleanup=True
)

print("Snowflake Schema diagram created: snowflake_schema.png")


# =========================================================
# 5. STORE TABLES IN SQLITE DATABASE
# =========================================================

conn = sqlite3.connect("retail_star_snowflake.db")

dim_product.to_sql(
    "dim_product",
    conn,
    if_exists="replace",
    index=False
)

dim_customer.to_sql(
    "dim_customer",
    conn,
    if_exists="replace",
    index=False
)

dim_store.to_sql(
    "dim_store",
    conn,
    if_exists="replace",
    index=False
)

dim_time.to_sql(
    "dim_time",
    conn,
    if_exists="replace",
    index=False
)

fact_sales.to_sql(
    "fact_sales",
    conn,
    if_exists="replace",
    index=False
)

dim_category.to_sql(
    "dim_category",
    conn,
    if_exists="replace",
    index=False
)

dim_product_snowflake.to_sql(
    "dim_product_snowflake",
    conn,
    if_exists="replace",
    index=False
)

print("\nAll tables stored in SQLite database.")


# =========================================================
# 6. SQL QUERY
# Total Sales by Category
# =========================================================

query = """
SELECT
    c.category_name,
    SUM(f.sales_amount) AS total_sales
FROM fact_sales f
JOIN dim_product_snowflake p
    ON f.product_id = p.product_id
JOIN dim_category c
    ON p.category_id = c.category_id
GROUP BY c.category_name;
"""

result = pd.read_sql_query(query, conn)

print("\n--- Total Sales by Category ---")
print(result)


# =========================================================
# 7. CLOSE DATABASE
# =========================================================

conn.close()

print("\nDatabase connection closed.")