from diagrams import Diagram, Cluster, Edge
from diagrams.onprem.client import Users
from diagrams.aws.compute import EC2
from diagrams.onprem.queue import Kafka
from diagrams.onprem.database import PostgreSQL
from diagrams.onprem.storage import Ceph
from diagrams.onprem.analytics import Spark
from diagrams.aws.analytics import Glue, Redshift

with Diagram("E-Commerce Data Architecture",
             filename="Ecommerce_Data_Architecture",
             show=True):

    user = Users("Customer")

    with Cluster("Source Systems"):
        web = EC2("Website / Mobile App")
        pos = EC2("POS System")
        crm = EC2("CRM")

    with Cluster("Data Ingestion Layer"):
        kafka = Kafka("Kafka")

    with Cluster("Storage Layer"):
        db = PostgreSQL("Order Database")
        lake = Ceph("Data Lake")

    with Cluster("Processing Layer"):
        spark = Spark("Spark Processing")
        glue = Glue("ETL Processing")

    with Cluster("Analytics & Serving Layer"):
        warehouse = Redshift("Data Warehouse")
        dashboard = EC2("Power BI / Tableau")

    user >> web
    user >> pos

    web >> kafka
    pos >> kafka
    crm >> kafka

    kafka >> db
    kafka >> lake

    db >> glue
    lake >> spark

    spark >> glue
    glue >> warehouse

    warehouse >> dashboard