from diagrams import Cluster, Diagram
from diagrams.aws.compute import EC2
from diagrams.aws.analytics import Glue, Redshift
from diagrams.onprem.analytics import Spark
from diagrams.onprem.client import Users
from diagrams.onprem.database import PostgreSQL
from diagrams.onprem.inmemory import Redis
from diagrams.onprem.queue import Kafka
from diagrams.onprem.storage import Ceph
from IPython.display import Image, display

with Diagram("Retail Web Platform - Conceptual Data Architecture", show=True, filename="Retail_Web_Architecture"):

    users = Users("Online Shoppers")

    with Cluster("Source Systems"):
        webapp = EC2("Web/App")
        pos = EC2("POS System")
        crm = EC2("CRM")

    with Cluster("Ingestion Layer"):
        kafka = Kafka("Kafka")
        redis = Redis("Cache")

    with Cluster("Storage Layer"):
        hdfs = Ceph("Data Lake")
        postgres = PostgreSQL("OLTP DB")

    with Cluster("Processing Layer"):
        spark = Spark("Spark Processing")
        glue = Glue("ETL Jobs")

    with Cluster("Serving Layer"):
        redshift = Redshift("DW/BI")
        dashboards = EC2("Tableau / Power BI")

    # Connections
    users >> webapp
    users >> pos
    webapp >> kafka
    pos >> kafka
    crm >> kafka

    kafka >> redis
    kafka >> hdfs
    kafka >> postgres

    redis >> spark
    hdfs >> spark
    postgres >> glue
    spark >> glue

    glue >> redshift
    redshift >> dashboards
